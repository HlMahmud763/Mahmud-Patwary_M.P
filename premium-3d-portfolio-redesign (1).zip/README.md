<div align="center">

# Mahmud Patwary (MP)

**Programmer · Web Developer · Graphics Designer**
Dhaka, Bangladesh — available all over the world

A cinematic, scroll-driven 3D portfolio built with React, Three.js and Framer Motion.
Ships as **one self-contained `index.html`** — so deploying it is almost effortless.

`mahmudpatwary763@gmail.com` · `+880 1792 644763`

</div>

---

## 🚀 Deploy করা (সবচেয়ে সহজ উপায় — Automatic)

এই রেপোতে GitHub Actions workflow আগে থেকেই বসানো আছে। আপনাকে শুধু **একবার** Pages চালু করতে হবে, তারপর প্রতিটি `git push`-এ সাইট নিজে নিজেই লাইভ হয়ে যাবে।

> ⚠️ **গুরুত্বপূর্ণ** — আপনার পুরনো রেপোতে যদি Pages আগে থেকেই **“Deploy from a branch → `main` → `/ (root)`”** সেট করা থাকে, তাহলে এই প্রজেক্ট push করার পর root-এর `index.html` টা Vite-এর source ফাইল হয়ে যাবে এবং সাইট সাময়িকভাবে ভাঙা দেখাবে।
> **সমাধান:** push করার সাথে সাথেই **Settings → Pages → Source = “GitHub Actions”** করে দিন। ১–২ মিনিটে Actions build শেষ হয়ে ঠিক হয়ে যাবে।
> (পুরনো ভার্সন সেভ রাখতে চাইলে আগে `git checkout -b backup-classic` করে একটি backup branch বানিয়ে নিন।)

### ধাপ ১ — Repository তৈরি ও push

```bash
git init
git add .
git commit -m "feat: premium 3D portfolio website"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

> 💡 আপনার বর্তমান রেপোতেই রাখতে চাইলে `git remote add` বাদ দিয়ে সরাসরি ফাইলগুলো commit করে push করুন।

### ধাপ ২ — Deploy দেখুন (Pages নিজেই চালু হয়ে যাবে)

Repository → **Actions** ট্যাব খুলুন → *“Deploy to GitHub Pages”* workflow চলছে দেখবেন।

workflow-এ `enablement: true` দেওয়া আছে, তাই **প্রথমবার GitHub Pages নিজে নিজেই enable হয়ে যাবে** — Settings-এ হাত দিতে হবে না। সবুজ ✅ হলে সাইট লাইভ:

```
https://<your-username>.github.io/<your-repo>/
```

**এরপর থেকে আর কিছু করতে হবে না** — কোড এডিট করে `git push` দিলেই ১–২ মিনিটে নতুন ভার্সন লাইভ।

<details>
<summary><b>যদি Pages অটো-enable না হয় (পুরনো রেপো / org permission)</b></summary>

ম্যানুয়ালি একবার সেট করে নিন:

1. Repository → **Settings** → বাম মেনুতে **Pages**
2. **Build and deployment** → *Source* = **GitHub Actions**
3. Actions ট্যাবে গিয়ে workflow আবার **Re-run** করুন

⚠️ Organization রেপো হলে **Settings → Actions → General → Workflow permissions** এ
*“Read and write permissions”* সিলেক্ট করা থাকতে হবে।

</details>

---

## ⚡ বিকল্প ১ — One command (gh-pages branch)

Actions ব্যবহার করতে না চাইলে, নিজের মেশিন থেকে এক কমান্ডে deploy:

```bash
# macOS / Linux / Git Bash
bash scripts/deploy.sh
```

```powershell
# Windows PowerShell
powershell -ExecutionPolicy Bypass -File scripts\deploy.ps1
```

তারপর **Settings → Pages → Source = “Deploy from a branch” → Branch = `gh-pages` → Folder = `/ (root)`** সেট করুন।

---

## 🖱️ বিকল্প ২ — Zero tooling (drag & drop)

পুরো সাইটটা **একটি মাত্র ফাইল** — সমস্ত JS, CSS, ফন্ট-লোডার সব ভিতরেই ইনলাইন করা। তাই Node.js ছাড়াও deploy করা যায়:

```bash
npm install
npm run build
```

`dist/` ফোল্ডারে পাবেন:

| ফাইল | কাজ |
| --- | --- |
| `index.html` | **পুরো ওয়েবসাইট** (একাই যথেষ্ট) |
| `404.html` | ব্র্যান্ডেড error পেজ |
| `og-image.jpg` | Facebook / WhatsApp / Twitter share preview |
| `robots.txt` · `sitemap.xml` | SEO |
| `.nojekyll` | GitHub Pages কে বলে Jekyll চালাতে হবে না |

এই ফোল্ডারের সব ফাইল GitHub-এর web UI থেকেই **Add file → Upload files** করে দিলেই চলবে, অথবা `index.html` টা Netlify / Vercel / Cloudflare Pages-এ টেনে ফেলে দিলেই লাইভ।

---

## 🌐 Custom domain (ঐচ্ছিক)

নিজের ডোমেইন ব্যবহার করতে চাইলে:

1. `public/` ফোল্ডারে `CNAME` নামে একটি ফাইল বানান, ভিতরে শুধু ডোমেইন লিখুন:
   ```
   mahmudpatwary.com
   ```
2. DNS-এ একটি `CNAME` রেকর্ড যোগ করুন → `www` → `<username>.github.io`
3. **Settings → Pages → Custom domain** এ ডোমেইন বসান, **Enforce HTTPS** চালু করুন
4. `index.html`, `public/robots.txt` ও `public/sitemap.xml`-এ `hlmahmud763.github.io/Mahmud-Patwary_M.P` অংশটা আপনার নতুন ডোমেইন দিয়ে বদলে দিন (share-preview ও SEO ঠিক থাকার জন্য)।

---

## ✏️ কনটেন্ট এডিট করা

**সব টেক্সট, ছবি ও লিংক এক জায়গায়** → `src/data/content.ts`

```ts
export const site = {
  name: "Mahmud Patwary",
  email: "mahmudpatwary763@gmail.com",
  phone: "+880 1792 644763",
  whatsapp: "https://wa.me/8801792644763",
  facebook: "https://www.facebook.com/hlmahmud.mp",
  instagram: "https://instagram.com/hlmahmud.mp",
  telegram: "https://t.me/HlMahmud763",
  github: "https://github.com/HlMahmud763",
  location: "Dhaka, Bangladesh",
  availability: "All over the world",
};
```

| আপনি যা বদলাতে চান | ফাইল |
| --- | --- |
| নাম, ইমেইল, ফোন, সোশ্যাল লিংক | `src/data/content.ts` → `site` |
| নতুন প্রজেক্ট / লাইভ ওয়েবসাইট যোগ করা | `src/data/content.ts` → `projects`, `liveWebsites` |
| ক্যালিগ্রাফি / গ্রাফিক্স ডিজাইন | `src/data/content.ts` → `graphics` |
| সার্টিফিকেট | `src/data/content.ts` → `certificates` |
| About লেখা | `src/data/content.ts` → `about` |
| সেকশনের ডিজাইন / লেআউট | `src/components/<SectionName>.tsx` |
| কালার, ফন্ট, অ্যানিমেশন | `src/index.css` (`@theme` ব্লক) |

নতুন ছবি যোগ করতে: ফাইলটি `public/images/` এ রাখুন, তারপর `content.ts`-এ `/images/your-file.jpg` লিখুন।

---

## 🛠️ Local development

```bash
npm install     # একবারই
npm run dev     # http://localhost:5173
npm run build   # production build → dist/
npm run preview # build করা ভার্সন লোকালি দেখা
```

**Requirements:** Node.js 18+ (20 recommended)

---

## 📁 প্রজেক্ট স্ট্রাকচার

```
├── .github/workflows/deploy.yml   ← Automatic GitHub Pages deploy
├── public/                        ← Static files (copied as-is into dist/)
│   ├── 404.html  og-image.jpg  robots.txt  sitemap.xml  .nojekyll
├── scripts/
│   ├── deploy.sh                  ← One-command deploy (macOS/Linux)
│   └── deploy.ps1                 ← One-command deploy (Windows)
├── src/
│   ├── components/
│   │   ├── three/                 ← WebGL scenes
│   │   │   ├── shared.tsx         ← Materials, studio lighting, gold dust
│   │   │   ├── HeroScene.tsx      ← Floating screens, torus knot, halos
│   │   │   └── StoryScene.tsx     ← Scroll-scrubbed "website builds itself"
│   │   ├── Hero.tsx               ← 3D hero + original image slider
│   │   ├── ScrollStory.tsx        ← Pinned 420vh scroll narrative
│   │   ├── Projects.tsx           ← Work grid
│   │   ├── WebDesigns.tsx         ← Features + browser mockup + live sites
│   │   ├── Graphics.tsx           ← Calligraphy gallery + lightbox
│   │   ├── Achievements.tsx       ← Stats, milestones, 3D certificates
│   │   ├── About.tsx              ← Parallax portrait + rotating seal
│   │   ├── Contact.tsx            ← Contact cards, socials, form, footer
│   │   ├── Navbar.tsx             ← Glass nav + active-section tracking
│   │   ├── BackToTop.tsx          ← Floating button with progress ring
│   │   ├── Preloader.tsx          ← Cinematic intro
│   │   ├── Cursor.tsx             ← Custom gold cursor
│   │   └── ui.tsx                 ← Reveal, SplitWords, TiltCard, Magnetic…
│   ├── data/content.ts            ← ✏️ ALL editable content lives here
│   ├── hooks/useLenis.ts          ← Smooth scrolling + scroll lock
│   ├── index.css                  ← Design tokens (colour, type, motion)
│   └── App.tsx
└── index.html
```

---

## 🎨 Design system

| Token | Value | Use |
| --- | --- | --- |
| Ivory | `#f4f0e6` `#faf8f3` | Off-white surfaces |
| Gold | `#c9a961` `#e2cf9a` `#9c7b3a` | Accents, rules, CTAs |
| Forest | `#0b1812` → `#2b4a37` | Deep green grounds |
| Display | **Cormorant Garamond** | Headlines |
| Body | **Manrope** | Everything else |

Hover behaviour: ivory sections glow **green**, forest sections glow **gold** — see the `hover-glow-green` / `hover-glow-gold` utilities in `src/index.css`.

---

## 🧰 Stack

React 19 · TypeScript · Vite 7 · Tailwind CSS 4 · Three.js + React Three Fiber + Drei · Framer Motion · Lenis

---

## ⚠️ Troubleshooting

| সমস্যা | সমাধান |
| --- | --- |
| Actions ট্যাবে কোনো workflow নেই | `.github/workflows/deploy.yml` ফাইলটি `main` branch-এ আছে কিনা দেখুন |
| Actions লাল ❌ — “Pages not enabled” | Settings → Pages → Source = **GitHub Actions** সেট করে workflow **Re-run** করুন |
| Org রেপোতে permission error | Settings → Actions → General → Workflow permissions = **Read and write** |
| সাইট 404 দেখাচ্ছে | Settings → Pages → Source = **GitHub Actions** সেট করা আছে তো? প্রথম deploy-এ ২–৫ মিনিট লাগে |
| সাইটে পুরনো ডিজাইন দেখাচ্ছে | Pages এখনো `main` branch থেকে serve করছে → Source বদলে **GitHub Actions** করুন |
| ছবি/স্টাইল ভাঙা দেখাচ্ছে | না ভাঙার কথা — সব inline। ব্রাউজার cache hard-refresh করুন (`Ctrl+Shift+R`) |
| GitHub raw ছবি লোড হচ্ছে না | `src/data/content.ts`-এর `REPO` ভেরিয়েবলে রেপো নাম ঠিক আছে কিনা দেখুন |
| `npm ci` fails | রেপোতে `package-lock.json` commit করুন (workflow `npm install`-এ fallback করে) |
| Deploy দেরি হচ্ছে | Pages-এ প্রথমবার ২–৫ মিনিট লাগে; পরে ১ মিনিটের কম |

---

<div align="center">

© 2026 **Mahmud Patwary (MP)** — All Rights Reserved.

Crafted with ◆ in Dhaka, Bangladesh

</div>
