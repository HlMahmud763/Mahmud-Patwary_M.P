#
# One-command manual deploy for GitHub Pages (Windows PowerShell).
#
#   powershell -ExecutionPolicy Bypass -File scripts\deploy.ps1
#
# Use this only if you prefer NOT to use the GitHub Action
# (.github/workflows/deploy.yml), which deploys automatically on every push.
# This script publishes the built site to a `gh-pages` branch instead.

$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

Write-Host ""
Write-Host "  ◆  Mahmud Patwary (MP) - GitHub Pages deploy" -ForegroundColor Yellow
Write-Host "  --------------------------------------------"

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Write-Host "X Node.js not found. Install it from https://nodejs.org" -ForegroundColor Red
  exit 1
}

Write-Host "-> [1/4] Installing dependencies..."
if (Test-Path package-lock.json) { npm ci } else { npm install }

Write-Host "-> [2/4] Building site..."
npm run build
if ($LASTEXITCODE -ne 0) { Write-Host "X Build failed" -ForegroundColor Red; exit 1 }

Write-Host "-> [3/4] Marking build as static (no Jekyll)..."
New-Item -ItemType File -Force -Path "dist/.nojekyll" | Out-Null

Write-Host "-> [4/4] Publishing to the gh-pages branch..."
$stamp = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
npx --yes gh-pages -d dist --nojekyll -m "chore: deploy site $stamp [skip ci]"
if ($LASTEXITCODE -ne 0) { Write-Host "X Publish failed" -ForegroundColor Red; exit 1 }

Write-Host ""
Write-Host "  OK  Published." -ForegroundColor Green
Write-Host "  Now open:  Repository -> Settings -> Pages"
Write-Host "  Set Source = 'Deploy from a branch', Branch = 'gh-pages', Folder = '/ (root)'"
Write-Host "  Your site will be live at: https://<username>.github.io/<repo>/"
Write-Host ""
