#!/usr/bin/env bash
#
# One-command manual deploy for GitHub Pages.
#
#   bash scripts/deploy.sh
#
# Use this only if you prefer NOT to use the GitHub Action
# (.github/workflows/deploy.yml), which deploys automatically on every push.
# This script publishes the built site to a `gh-pages` branch instead.

set -euo pipefail
cd "$(dirname "$0")/.."

echo ""
echo "  ◆  Mahmud Patwary (MP) — GitHub Pages deploy"
echo "  ────────────────────────────────────────────"

command -v node >/dev/null 2>&1 || { echo "✖ Node.js not found. Install it from https://nodejs.org"; exit 1; }
command -v npm  >/dev/null 2>&1 || { echo "✖ npm not found."; exit 1; }

echo "→ [1/4] Installing dependencies…"
if [ -f package-lock.json ]; then npm ci; else npm install; fi

echo "→ [2/4] Building site…"
npm run build

echo "→ [3/4] Marking build as static (no Jekyll)…"
touch dist/.nojekyll

echo "→ [4/4] Publishing to the gh-pages branch…"
npx --yes gh-pages -d dist --nojekyll -m "chore: deploy site $(date -u +%Y-%m-%dT%H:%M:%SZ) [skip ci]"

echo ""
echo "  ✅  Published."
echo "  Now open:  Repository → Settings → Pages"
echo "  Set Source = 'Deploy from a branch', Branch = 'gh-pages', Folder = '/ (root)'"
echo "  Your site will be live at: https://<username>.github.io/<repo>/"
echo ""
